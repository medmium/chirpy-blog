#!/system/bin/sh

# 确保以 root 运行
[ "$(id -u)" = "0" ] || exit 1

# 配置：模块 ID 必须与 /data/adb/modules/ 下的文件夹名一致
MODULE_ID="adb-tcp"
DISABLE_FILE="/data/adb/modules/$MODULE_ID/disable"
LOG_FILE="/data/adb/adb_tcp.log"
LOG_TAG="ADB_TCP_AUTO"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$LOG_TAG] $*" >> "$LOG_FILE"
}


log "Starting keep-alive service..."
#禁用5555端口的本地回环
iptables -A OUTPUT -p tcp --dport 5555 -d 127.0.0.1 -j DROP
# 设置 ADB TCP 端口
setprop service.adb.tcp.port 5555

# 等待系统初始化完成
sleep 10

# 启动 adbd
stop adbd 2>/dev/null
start adbd 2>/dev/null
log "Initial adbd started."

# 后台监控循环（支持运行时响应禁用）
(
    while true; do
        # 检查是否被 Magisk 禁用（动态生效）
        if [ -f "$DISABLE_FILE" ]; then
            log "Module disabled during runtime. Stopping adbd."
            stop adbd 2>/dev/null
        # 检查 5555 端口是否处于 LISTEN 状态
        elif ! netstat -tuln 2>/dev/null | grep -q ':5555 .*LISTEN'; then
            log "Port 5555 not listening. Restarting adbd..."
            stop adbd 2>/dev/null
            start adbd 2>/dev/null
            sleep 1
            if netstat -tuln 2>/dev/null | grep -q ':5555 .*LISTEN'; then
                log "adbd restarted successfully."
            else
                log "Failed to restart adbd or port still not open."
            fi
        fi

        sleep 2
    done
) &

log "Monitor loop started in background."