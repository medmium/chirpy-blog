/* android-config.h - minimal config for Android */
#define HAVE_LIBV4L2 0
#define HAVE_LIBV4LCONVERT 0
#define HAVE_JPEG 0
#define HAVE_SYS_VFS_H 0
#define HAVE_LINUX_MEDIA_H 1
#define HAVE_LINUX_VIDEODEV2_H 1
#define HAVE_POSIX_MEMALIGN 1
#define HAVE_CLOCK_GETTIME 1
#define HAVE_STRCASECMP 1
#define HAVE_STRNCASECMP 1
#define HAVE_FSTATAT 1
#define HAVE_PWRITE 1
#define HAVE_PREAD 1
#define HAVE_MMAP 1
#define HAVE_SYS_STAT_H 1
#define HAVE_UNISTD_H 1
#define HAVE_FCNTL_H 1
#define HAVE_DIRENT_H 1
#define HAVE_ENDIAN_H 1
#define HAVE_SYS_IOCTL_H 1
#define HAVE_LINUX_TYPES_H 1
#define HAVE_ASM_TYPES_H 0
#define HAVE_SYS_UIO_H 1
#define ANDROID 1

/* Disable features not available on Android */
#define HAVE_GLOB_H 0
#define HAVE_EXECINFO_H 0
#define HAVE_BACKTRACE 0
#define HAVE_DLFCN_H 0
#define HAVE_LIBDL 0
#define HAVE_ICONV 0
#define HAVE_LANGINFO_H 0
#define HAVE_NL_LANGINFO 0
#define HAVE_GETTEXT 0
#define HAVE_LIBUTIL_H 0
#define HAVE_DEV_VIDEO 1
