
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/codec-fwht.c" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/codec-fwht.c.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/codec-fwht.c.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/codec-v4l2-fwht.c" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/codec-v4l2-fwht.c.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/codec-v4l2-fwht.c.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l-stream.c" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l-stream.c.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l-stream.c.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-tpg-colors.c" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-tpg-colors.c.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-tpg-colors.c.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-tpg-core.c" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-tpg-core.c.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-tpg-core.c.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/media-info.cpp" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/media-info.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/media-info.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-info.cpp" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-info.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/common/v4l2-info.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-common.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-common.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-common.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-edid.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-edid.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-edid.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-io.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-io.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-io.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-meta.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-meta.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-meta.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-misc.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-misc.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-misc.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-modes.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-modes.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-modes.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-overlay.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-overlay.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-overlay.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-sdr.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-sdr.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-sdr.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-selection.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-selection.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-selection.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-stds.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-stds.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-stds.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-streaming.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-streaming.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-streaming.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-subdev.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-subdev.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-subdev.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-tuner.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-tuner.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-tuner.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-vbi.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-vbi.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-vbi.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-vidcap.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-vidcap.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-vidcap.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl-vidout.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-vidout.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl-vidout.cpp.o.d"
  "/mnt/c/Users/daily/MyFile/asset/0tempdownload/v4l-utils/utils/v4l2-ctl/v4l2-ctl.cpp" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl.cpp.o" "gcc" "CMakeFiles/v4l2-ctl.dir/v4l2-ctl.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
