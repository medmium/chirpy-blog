# Empty compiler generated dependencies file for v4l2-ctl.
# This may be replaced when dependencies are built.
